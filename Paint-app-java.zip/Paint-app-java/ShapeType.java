package se.iths.tt.javafxtt.Paint;

public enum ShapeType {
}
