package se.iths.tt.javafxtt.Paint;
//regret
public interface Command {
    void execute();
}
